<footer>
    <div class="line"></div>
    <div class="container-footer">
        <h5>&copy; PHP motors, All Rights reserved<br>
        All images used are believed in "Fair Use". Please notify the autor if any are not and they will be removed<br>
        Last Update: xx xxxx, xxxx</h5>
    </div>
</footer>