<nav >
    <?php echo $navList; ?>
</nav>